import { createContext, useContext, useReducer } from 'react'
import { INITIAL_TRANSACTIONS, INITIAL_INVESTMENTS, INITIAL_DREAMS } from '../data/constants'

const AppContext = createContext(null)

const initialState = {
  transactions: INITIAL_TRANSACTIONS,
  investments: INITIAL_INVESTMENTS,
  dreams: INITIAL_DREAMS,
  xp: 2350,
  user: null,
  notifications: [
    {id:1,t:'warn',e:'⚠️',tx:'Você gastou 78% do limite de Alimentação este mês.',tm:'Agora',r:false},
    {id:2,t:'tip',e:'💡',tx:'3 compras por impulso detectadas! Use o Verificador de Compra.',tm:'2h atrás',r:false},
    {id:3,t:'win',e:'🏆',tx:'Você poupou mais de 20% da renda este mês!',tm:'Ontem',r:false},
    {id:4,t:'tip',e:'📊',tx:'Gasto com Delivery cresceu 35% vs o mês passado.',tm:'2 dias',r:true},
    {id:5,t:'inv',e:'📈',tx:'Tesouro Selic acima de 13% a.a. Boa hora para reforçar a reserva.',tm:'3 dias',r:true},
  ]
}

function reducer(state, action) {
  switch (action.type) {
    case 'ADD_TRANSACTION':
      return { ...state, transactions: [...state.transactions, action.payload], xp: state.xp + 20 }
    case 'ADD_INVESTMENT':
      return { ...state, investments: [...state.investments, action.payload], xp: state.xp + 30 }
    case 'ADD_DREAM':
      return { ...state, dreams: [...state.dreams, action.payload], xp: state.xp + 50 }
    case 'DEPOSIT_DREAM':
      return {
        ...state,
        dreams: state.dreams.map((d,i) =>
          i === action.idx ? {...d, current: Math.min(d.target, d.current + action.amount)} : d
        ),
        xp: state.xp + Math.round(action.amount / 10)
      }
    case 'SET_USER':
      return { ...state, user: action.payload, xp: state.xp + 100 }
    case 'READ_NOTIF':
      return { ...state, notifications: state.notifications.map((n,i) => i===action.idx ? {...n,r:true} : n) }
    case 'READ_ALL_NOTIFS':
      return { ...state, notifications: state.notifications.map(n => ({...n,r:true})) }
    default:
      return state
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState)
  const calcStats = () => {
    const inc = state.transactions.filter(t=>t.type==='income').reduce((a,t)=>a+t.val,0)
    const exp = state.transactions.filter(t=>t.type!=='income').reduce((a,t)=>a+t.val,0)
    const bal = inc - exp
    const sav = inc > 0 ? Math.round((Math.max(0,bal)/inc)*100) : 0
    return { inc, exp, bal, sav }
  }
  return (
    <AppContext.Provider value={{ state, dispatch, calcStats }}>
      {children}
    </AppContext.Provider>
  )
}

export const useApp = () => useContext(AppContext)
