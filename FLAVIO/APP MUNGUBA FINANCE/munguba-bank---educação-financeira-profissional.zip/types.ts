
export enum TransactionType {
  FIXED = 'FIXO',
  VARIABLE = 'VARIÁVEL',
  INCOME = 'RECEITA'
}

export enum InvestmentType {
  FIXED_INCOME = 'RENDA FIXA',
  VARIABLE_INCOME = 'RENDA VARIÁVEL'
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  category: string;
  value: number;
  type: TransactionType;
}

export interface Investment {
  id: string;
  assetName: string;
  type: InvestmentType;
  value: number; // Valor total do aporte (preço * quantidade)
  price: number; // Preço unitário na compra
  quantity: number; // Quantidade comprada
  date: string;
}

export interface Bill {
  id: string;
  issuer: string;
  dueDate: string;
  value: number;
  status: 'Pendente' | 'Pago' | 'Atrasado';
  barcode: string;
}

export interface UserProfile {
  name: string;
  cpf: string;
}

export interface DashboardStats {
  totalIncome: number;
  totalFixed: number;
  totalVariable: number;
  balance: number;
  fixedPercentage: number;
  variablePercentage: number;
}
