
import React, { useState, useMemo, useEffect } from 'react';
import { 
  LayoutDashboard, 
  ArrowDownLeft, 
  PieChart as PieIcon, 
  Wallet, 
  TrendingUp, 
  PlusCircle, 
  History,
  Settings,
  AlertTriangle,
  ArrowUpRight,
  Lightbulb,
  GraduationCap,
  Info,
  ChevronRight,
  LogIn,
  LogOut,
  User as UserIcon,
  TrendingDown,
  ArrowUpCircle,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  ReceiptText
} from 'lucide-react';
import { 
  ResponsiveContainer as ReResponsiveContainer, 
  BarChart as ReBarChart, 
  Bar as ReBar, 
  XAxis as ReXAxis, 
  YAxis as ReYAxis, 
  CartesianGrid as ReCartesianGrid, 
  Tooltip as ReTooltip,
  AreaChart as ReAreaChart,
  Area as ReArea,
  PieChart as RePieChart,
  Pie as RePie,
  Cell as ReCell
} from 'recharts';
import { GoogleGenAI } from "@google/genai";
import { Transaction, TransactionType, Investment, InvestmentType, UserProfile } from './types';
import Dashboard from './components/Dashboard';
import TransactionList from './components/TransactionList';
import InvestmentTracker from './components/InvestmentTracker';
import AddTransactionModal from './components/AddTransactionModal';
import SettingsPage from './components/SettingsPage';
import EducationView from './components/EducationView';
import MungubaTips from './components/MungubaTips';
import AuthModal from './components/AuthModal';
import BillView from './components/BillView';

// Componente para a Árvore Munguba realista (Baseada na foto de referência enviada pelo usuário)
const MungubaLogo = () => {
  const [logoUrl, setLogoUrl] = useState<string | null>(null);

  useEffect(() => {
    const generateLogo = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [{ text: "A highly realistic, professional photograph of a single Munguba tree (Pachira aquatica) in a sunny park. Dense, lush rounded green canopy with dark emerald star-shaped leaves. Thick, textured brownish-grey trunk. Isolated on a clean white background as a high-end corporate asset. Natural sunlight, sharp details on foliage, very similar to a real-life botanical photo." }]
          },
          config: {
            imageConfig: { aspectRatio: "1:1" }
          }
        });

        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            setLogoUrl(`data:image/png;base64,${part.inlineData.data}`);
            break;
          }
        }
      } catch (e) {
        console.error("Erro ao gerar logo:", e);
      }
    };
    generateLogo();
  }, []);

  return (
    <div className="w-32 h-32 shrink-0 transition-transform duration-700 hover:scale-110 flex items-center justify-center">
      {logoUrl ? (
        <img 
          src={logoUrl} 
          alt="Munguba Realista" 
          className="w-full h-full object-contain mix-blend-multiply drop-shadow-md rounded-full bg-white/5" 
        />
      ) : (
        <div className="w-16 h-16 rounded-full border-4 border-[#1A4A36]/20 border-t-[#1A4A36] animate-spin" />
      )}
    </div>
  );
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'transactions' | 'fixed' | 'variable' | 'income' | 'investments' | 'education' | 'settings' | 'bills'>('dashboard');
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const [categories, setCategories] = useState<Record<TransactionType, string[]>>({
    [TransactionType.INCOME]: ['Salário', 'Dividendos', 'Freelance', 'Vendas', 'Outros'],
    [TransactionType.FIXED]: ['Aluguel', 'Educação', 'Saúde', 'Seguros', 'Internet'],
    [TransactionType.VARIABLE]: ['Alimentação', 'Lazer', 'Transporte', 'Viagens'],
  });

  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: '1', date: '2026-01-01', description: 'Salário Principal', category: 'Salário', value: 6500, type: TransactionType.INCOME },
    { id: '2', date: '2026-01-05', description: 'Aluguel Central', category: 'Aluguel', value: 2200, type: TransactionType.FIXED },
    { id: '3', date: '2026-01-10', description: 'Supermercado Mensal', category: 'Alimentação', value: 1200, type: TransactionType.VARIABLE },
    { id: '4', date: '2025-12-01', description: 'Salário Dezembro', category: 'Salário', value: 6500, type: TransactionType.INCOME },
    { id: '5', date: '2025-11-01', description: 'Freelance Design', category: 'Freelance', value: 2500, type: TransactionType.INCOME },
    { id: '6', date: '2026-01-15', description: 'Venda de Livros', category: 'Vendas', value: 300, type: TransactionType.INCOME },
    { id: '7', date: '2026-01-20', description: 'Academia', category: 'Saúde', value: 200, type: TransactionType.FIXED },
    { id: '8', date: '2026-01-22', description: 'Restaurante', category: 'Lazer', value: 450, type: TransactionType.VARIABLE },
    { id: '9', date: '2025-12-10', description: 'Natal Gastos', category: 'Lazer', value: 1500, type: TransactionType.VARIABLE },
  ]);
  
  const [investments, setInvestments] = useState<Investment[]>([
    { id: 'i1', assetName: 'B5P211', type: InvestmentType.FIXED_INCOME, value: 4000, price: 100, quantity: 40, date: '2026-01-10' },
  ]);
  
  const [isModalOpen, setIsModalOpen] = useState(false);

  const stats = useMemo(() => {
    const totalIncome = transactions.filter(t => t.type === TransactionType.INCOME).reduce((acc, t) => acc + t.value, 0);
    const totalFixed = transactions.filter(t => t.type === TransactionType.FIXED).reduce((acc, t) => acc + t.value, 0);
    const totalVariable = transactions.filter(t => t.type === TransactionType.VARIABLE).reduce((acc, t) => acc + t.value, 0);
    return {
      totalIncome,
      totalFixed,
      totalVariable,
      balance: totalIncome - (totalFixed + totalVariable),
      fixedPercentage: totalIncome > 0 ? (totalFixed / totalIncome) * 100 : 0,
      variablePercentage: totalIncome > 0 ? (totalVariable / totalIncome) * 100 : 0,
    };
  }, [transactions]);

  // Auxiliares para Gráficos
  const getCategoryData = (type: TransactionType) => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const filtered = transactions.filter(t => {
      const d = new Date(t.date);
      return t.type === type && d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });

    const categoriesMap: Record<string, { name: string, value: number, count: number }> = {};
    filtered.forEach(t => {
      if (!categoriesMap[t.category]) {
        categoriesMap[t.category] = { name: t.category, value: 0, count: 0 };
      }
      categoriesMap[t.category].value += t.value;
      categoriesMap[t.category].count += 1;
    });

    return Object.values(categoriesMap).sort((a, b) => b.value - a.value);
  };

  const getAnnualData = (type: TransactionType) => {
    const monthlyTotals: Record<number, number> = {};
    const currentYear = new Date().getFullYear();

    transactions.filter(t => {
        const d = new Date(t.date);
        return t.type === type && d.getFullYear() === currentYear;
    }).forEach(t => {
        const m = new Date(t.date).getMonth();
        monthlyTotals[m] = (monthlyTotals[m] || 0) + t.value;
    });

    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    return months.map((m, i) => ({
      name: m,
      valor: monthlyTotals[i] || 0
    }));
  };

  const addTransaction = (t: Omit<Transaction, 'id'>) => {
    setTransactions(prev => [...prev, { ...t, id: Math.random().toString(36).substr(2, 9) }]);
  };

  const handleLogin = (name: string, cpf: string) => {
    setUser({ name, cpf });
  };

  const handleLogout = () => {
    setUser(null);
    setActiveTab('dashboard');
  };

  const getActiveTitle = () => {
    switch(activeTab) {
      case 'dashboard': return 'Controle Financeiro';
      case 'transactions': return 'Lançamentos';
      case 'fixed': return 'Custos Fixos';
      case 'variable': return 'C. Variáveis';
      case 'income': return 'Receitas';
      case 'investments': return 'Investimentos';
      case 'education': return 'Educação';
      case 'settings': return 'Ajustes';
      case 'bills': return 'Boleto';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen bg-[#F7FFFA] flex flex-col md:flex-row font-sans">
      {/* Sidebar */}
      <nav className="w-full md:w-80 bg-[#DAF7DD] border-r border-black/5 p-6 flex flex-col sticky top-0 md:h-screen z-20 overflow-y-auto">
        <div className="flex flex-col mb-12">
          <div className="flex items-center gap-4">
            <MungubaLogo />
            <div className="flex flex-col">
              <h1 className="text-3xl font-black tracking-tighter text-[#1A4A36] leading-none">
                Munguba
              </h1>
              <span className="text-emerald-700 text-2xl font-bold tracking-tighter leading-none">Bank</span>
            </div>
          </div>
          {user && (
            <div className="mt-6 flex items-center gap-3 p-3 bg-white/40 rounded-2xl border border-emerald-900/10">
              <div className="bg-emerald-900 text-[#ADEBB3] p-1.5 rounded-lg"><UserIcon size={14}/></div>
              <div className="flex flex-col">
                <p className="text-[10px] font-black text-emerald-900 uppercase tracking-tighter leading-none">Olá, {user.name}</p>
                <p className="text-[8px] font-bold text-emerald-700 uppercase leading-none mt-1">{user.cpf}</p>
              </div>
            </div>
          )}
          <p className="text-[10px] font-black text-[#1A4A36]/60 uppercase tracking-[0.2em] leading-tight mt-4 px-2">
            Consultoria Profissional <br/> em Educação Financeira
          </p>
        </div>

        <div className="space-y-2 flex-1">
          <NavItem 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
            icon={<LayoutDashboard size={18}/>} 
            label="Controle Financeiro" 
            colorClass="text-[#1A4A36]" 
            activeBg="bg-[#1A4A36]" 
          />
          <NavItem 
            active={activeTab === 'transactions'} 
            onClick={() => setActiveTab('transactions')} 
            icon={<History size={18}/>} 
            label="Lançamentos" 
            colorClass="text-indigo-900" 
            activeBg="bg-indigo-900" 
          />
          
          <div className="pt-6 pb-2 text-[9px] font-black text-[#1A4A36]/30 uppercase tracking-[0.4em] ml-4 text-emerald-900/40">Fluxo de Caixa</div>
          <NavItem 
            active={activeTab === 'income'} 
            onClick={() => setActiveTab('income')} 
            icon={<ArrowUpRight size={18}/>} 
            label="Receitas" 
            colorClass="text-emerald-800" 
            activeBg="bg-emerald-800" 
          />
          <NavItem 
            active={activeTab === 'fixed'} 
            onClick={() => setActiveTab('fixed')} 
            icon={<ArrowDownLeft size={18}/>} 
            label="Custos Fixos" 
            colorClass="text-red-800" 
            activeBg="bg-red-800" 
          />
          <NavItem 
            active={activeTab === 'variable'} 
            onClick={() => setActiveTab('variable')} 
            icon={<PieIcon size={18}/>} 
            label="C. Variáveis" 
            colorClass="text-orange-700" 
            activeBg="bg-orange-700" 
          />
          
          <div className="pt-6 pb-2 text-[9px] font-black text-[#1A4A36]/30 uppercase tracking-[0.4em] ml-4 text-emerald-900/40">Patrimônio</div>
          <NavItem 
            active={activeTab === 'investments'} 
            onClick={() => setActiveTab('investments')} 
            icon={<TrendingUp size={18}/>} 
            label="Investimentos" 
            colorClass="text-blue-800" 
            activeBg="bg-blue-800" 
          />
          <NavItem 
            active={activeTab === 'bills'} 
            onClick={() => setActiveTab('bills')} 
            icon={<ReceiptText size={18}/>} 
            label="Boleto" 
            colorClass="text-slate-800" 
            activeBg="bg-slate-800" 
          />
          <NavItem 
            active={activeTab === 'education'} 
            onClick={() => setActiveTab('education')} 
            icon={<GraduationCap size={18}/>} 
            label="Educação" 
            colorClass="text-purple-800" 
            activeBg="bg-purple-800" 
          />
        </div>

        {/* Grupo de Ações do Rodapé do Sidebar */}
        <div className="mt-8 space-y-3 pt-6 border-t border-emerald-900/10">
          <button 
            onClick={() => setIsModalOpen(true)}
            className="w-full flex items-center justify-center gap-3 bg-[#1A4A36] text-[#ADEBB3] hover:bg-black hover:text-white font-black py-4 px-6 rounded-2xl transition-all shadow-xl active:scale-95 text-[10px] uppercase tracking-widest"
          >
            <PlusCircle size={18} />
            <span>Novo Registro</span>
          </button>

          <button 
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center justify-center gap-3 py-4 px-6 rounded-2xl transition-all font-black text-[10px] uppercase tracking-widest ${
              activeTab === 'settings' 
                ? 'bg-emerald-900 text-white shadow-lg' 
                : 'bg-white/40 text-emerald-900 hover:bg-white/60'
            }`}
          >
            <Settings size={18} />
            <span>Configurações</span>
          </button>

          {!user ? (
            <button 
              onClick={() => setIsAuthModalOpen(true)}
              className="w-full flex items-center justify-center gap-3 bg-white text-emerald-900 hover:bg-emerald-50 font-black py-4 px-6 rounded-2xl transition-all shadow-sm active:scale-95 text-[10px] uppercase tracking-widest border border-emerald-900/10"
            >
              <LogIn size={18} />
              <span>Login</span>
            </button>
          ) : (
            <button 
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-3 bg-red-50 text-red-900 hover:bg-red-100 font-black py-4 px-6 rounded-2xl transition-all shadow-sm active:scale-95 text-[10px] uppercase tracking-widest border border-red-900/10"
            >
              <LogOut size={18} />
              <span>Sair</span>
            </button>
          )}
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <header className="px-8 py-10 bg-white/70 backdrop-blur-xl border-b border-[#ADEBB3]/30 flex flex-col lg:flex-row lg:items-center justify-between gap-8 sticky top-0 z-10 transition-all">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between w-full gap-8">
            <div className="flex flex-col gap-1 shrink-0 group">
              <div className="flex items-center gap-4">
                <div className="w-1.5 h-8 bg-gradient-to-b from-[#1A4A36] to-emerald-400 rounded-full group-hover:scale-y-110 transition-transform shadow-sm"></div>
                <h2 className="text-2xl md:text-3xl font-black tracking-tighter uppercase italic font-serif bg-clip-text text-transparent bg-gradient-to-r from-[#1A4A36] via-[#1A4A36] to-emerald-600">
                  {getActiveTitle()}
                </h2>
              </div>
              <p className="text-[10px] font-black text-emerald-800/40 uppercase tracking-[0.5em] ml-6 leading-none">
                Gestão Patrimonial Estratégica
              </p>
            </div>

            {/* Dicas Munguba Compactas "Ao Lado" do Título */}
            {(activeTab === 'dashboard' || activeTab === 'income' || activeTab === 'fixed' || activeTab === 'variable' || activeTab === 'bills') && (
              <div className="flex-shrink-0 flex items-center">
                <MungubaTips variant="compact" />
              </div>
            )}
          </div>
        </header>

        <div className="p-8 md:p-12 space-y-12">
          {activeTab === 'dashboard' && <Dashboard stats={stats} transactions={transactions} investments={investments} />}
          
          {activeTab === 'income' && (
            <div className="space-y-8 animate-in fade-in duration-500">
              <div className="bg-gradient-to-br from-emerald-600 to-emerald-900 p-10 rounded-[3rem] text-white shadow-xl flex flex-col md:flex-row items-center justify-between overflow-hidden relative gap-8">
                <div className="absolute -right-10 -top-10 opacity-10"><ArrowUpCircle size={200}/></div>
                <div className="relative z-10">
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-emerald-200">Total de Receitas</span>
                  <h3 className="text-5xl font-black tracking-tighter mt-2">{stats.totalIncome.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</h3>
                  <p className="text-emerald-100/60 text-[10px] font-bold uppercase tracking-widest mt-4">Eficiência de Arrecadação Mensal</p>
                </div>
                
                <div className="flex flex-col items-end gap-2 text-right relative z-10">
                    <span className="text-[10px] font-black uppercase text-emerald-200 tracking-widest">Saldo Patrimonial</span>
                    <span className="text-3xl font-black">{(stats.totalIncome - stats.totalFixed - stats.totalVariable).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                </div>
              </div>

              {/* GRÁFICOS DE RECEITA */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                    <PieIcon size={14} className="text-emerald-500"/> Fontes de Receita (Mensal)
                  </h4>
                  <div className="h-[250px]">
                    <ReResponsiveContainer>
                      <ReBarChart data={getCategoryData(TransactionType.INCOME)} layout="vertical">
                        <ReCartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                        <ReXAxis type="number" hide />
                        <ReYAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={80} style={{fontSize: '10px', fontWeight: 'bold'}} />
                        <ReTooltip 
                           cursor={{fill: '#f8fafc'}}
                           contentStyle={{borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}}
                           formatter={(value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        />
                        <ReBar dataKey="value" fill="#10b981" radius={[0, 10, 10, 0]} barSize={20} />
                      </ReBarChart>
                    </ReResponsiveContainer>
                  </div>
                </div>

                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                    <TrendingUp size={14} className="text-emerald-500"/> Evolução Anual de Receitas
                  </h4>
                  <div className="h-[250px]">
                    <ReResponsiveContainer>
                      <ReAreaChart data={getAnnualData(TransactionType.INCOME)}>
                        <defs>
                          <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <ReXAxis dataKey="name" axisLine={false} tickLine={false} style={{fontSize: '10px', fontWeight: 'bold'}} />
                        <ReYAxis hide />
                        <ReTooltip 
                           contentStyle={{borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}}
                           formatter={(value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        />
                        <ReArea type="monotone" dataKey="valor" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorIncome)" />
                      </ReAreaChart>
                    </ReResponsiveContainer>
                  </div>
                </div>
              </div>

              <TransactionList transactions={transactions.filter(t => t.type === TransactionType.INCOME)} />
            </div>
          )}

          {activeTab === 'fixed' && (
            <div className="space-y-8 animate-in fade-in duration-500">
              <div className="bg-gradient-to-br from-red-600 to-red-900 p-10 rounded-[3rem] text-white shadow-xl flex flex-col md:flex-row items-center justify-between overflow-hidden relative gap-8">
                <div className="absolute -right-10 -top-10 opacity-10"><TrendingDown size={200}/></div>
                <div className="relative z-10">
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-red-200">Total de Custos Fixos</span>
                  <h3 className="text-5xl font-black tracking-tighter mt-2">{stats.totalFixed.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</h3>
                  <p className="text-red-100/60 text-[10px] font-bold uppercase tracking-widest mt-4">Estrutura de Gastos Inegociáveis</p>
                </div>

                <div className="flex flex-col items-end gap-2 text-right relative z-10">
                    <span className="text-[10px] font-black uppercase text-red-200 tracking-widest">Peso no Orçamento</span>
                    <span className="text-3xl font-black">{stats.fixedPercentage.toFixed(1)}%</span>
                </div>
              </div>

              {/* GRÁFICOS DE CUSTOS FIXOS */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm">
                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                    <PieIcon size={14} className="text-red-500"/> Composição Mensal de Custos Fixos
                  </h4>
                  <div className="h-[250px]">
                    <ReResponsiveContainer>
                      <RePieChart>
                        <RePie 
                           data={getCategoryData(TransactionType.FIXED)} 
                           innerRadius={60} 
                           outerRadius={85} 
                           paddingAngle={5} 
                           dataKey="value"
                           stroke="none"
                        >
                          {getCategoryData(TransactionType.FIXED).map((_, i) => (
                            <ReCell key={i} fill={['#ef4444', '#b91c1c', '#7f1d1d', '#f87171', '#fca5a5'][i % 5]} />
                          ))}
                        </RePie>
                        <ReTooltip 
                           contentStyle={{borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}}
                           formatter={(value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        />
                      </RePieChart>
                    </ReResponsiveContainer>
                  </div>
                  <div className="flex flex-wrap justify-center gap-4 mt-4">
                      {getCategoryData(TransactionType.FIXED).map((cat, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{backgroundColor: ['#ef4444', '#b91c1c', '#7f1d1d', '#f87171', '#fca5a5'][i % 5]}} />
                          <span className="text-[10px] font-bold text-slate-600 uppercase">{cat.name}</span>
                        </div>
                      ))}
                  </div>
                </div>

                <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm">
                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                    <TrendingUp size={14} className="text-red-500"/> Histórico Anual de Fixos
                  </h4>
                  <div className="h-[250px]">
                    <ReResponsiveContainer>
                      <ReBarChart data={getAnnualData(TransactionType.FIXED)}>
                        <ReXAxis dataKey="name" axisLine={false} tickLine={false} style={{fontSize: '10px', fontWeight: 'bold'}} />
                        <ReYAxis hide />
                        <ReTooltip 
                           contentStyle={{borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}}
                           formatter={(value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        />
                        <ReBar dataKey="valor" fill="#ef4444" radius={[10, 10, 0, 0]} />
                      </ReBarChart>
                    </ReResponsiveContainer>
                  </div>
                </div>
              </div>

              <TransactionList transactions={transactions.filter(t => t.type === TransactionType.FIXED)} />
            </div>
          )}

          {activeTab === 'variable' && (
            <div className="space-y-8 animate-in fade-in duration-500">
              <div className="bg-gradient-to-br from-orange-500 to-orange-800 p-10 rounded-[3rem] text-white shadow-xl flex flex-col md:flex-row items-center justify-between overflow-hidden relative gap-8">
                <div className="absolute -right-10 -top-10 opacity-10"><PieIcon size={200}/></div>
                <div className="relative z-10">
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-orange-200">Total de Custos Variáveis</span>
                  <h3 className="text-5xl font-black tracking-tighter mt-2">{stats.totalVariable.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</h3>
                  <p className="text-orange-100/60 text-[10px] font-bold uppercase tracking-widest mt-4">Gestão de Estilo de Vida e Lazer</p>
                </div>

                <div className="flex flex-col items-end gap-2 text-right relative z-10">
                    <span className="text-[10px] font-black uppercase text-orange-200 tracking-widest">Peso no Orçamento</span>
                    <span className="text-3xl font-black">{stats.variablePercentage.toFixed(1)}%</span>
                </div>
              </div>

              {/* GRÁFICOS DE CUSTOS VARIÁVEIS */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm">
                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                    <PieIcon size={14} className="text-orange-500"/> Detalhamento Variável (Mensal)
                  </h4>
                  <div className="h-[250px]">
                    <ReResponsiveContainer>
                      <ReBarChart data={getCategoryData(TransactionType.VARIABLE)} layout="vertical">
                        <ReCartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                        <ReXAxis type="number" hide />
                        <ReYAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={80} style={{fontSize: '10px', fontWeight: 'bold'}} />
                        <ReTooltip 
                           contentStyle={{borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}}
                           formatter={(value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        />
                        <ReBar dataKey="value" fill="#f97316" radius={[0, 10, 10, 0]} barSize={20} />
                      </ReBarChart>
                    </ReResponsiveContainer>
                  </div>
                </div>

                <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm">
                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center gap-2">
                    <TrendingUp size={14} className="text-orange-500"/> Consolidação Anual Variável
                  </h4>
                  <div className="h-[250px]">
                    <ReResponsiveContainer>
                      <ReAreaChart data={getAnnualData(TransactionType.VARIABLE)}>
                        <defs>
                          <linearGradient id="colorVar" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#f97316" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <ReXAxis dataKey="name" axisLine={false} tickLine={false} style={{fontSize: '10px', fontWeight: 'bold'}} />
                        <ReYAxis hide />
                        <ReTooltip 
                           contentStyle={{borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}}
                           formatter={(value: number) => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        />
                        <ReArea type="monotone" dataKey="valor" stroke="#f97316" strokeWidth={3} fillOpacity={1} fill="url(#colorVar)" />
                      </ReAreaChart>
                    </ReResponsiveContainer>
                  </div>
                </div>
              </div>

              <TransactionList transactions={transactions.filter(t => t.type === TransactionType.VARIABLE)} />
            </div>
          )}

          {activeTab === 'bills' && <BillView user={user} />}
          {activeTab === 'transactions' && <TransactionList transactions={transactions} />}
          {activeTab === 'investments' && <InvestmentTracker investments={investments} onAdd={() => {}} />}
          {activeTab === 'education' && <EducationView stats={stats} />}
          {activeTab === 'settings' && <SettingsPage categories={categories} onUpdateCategories={setCategories} />}
        </div>
      </main>

      <AddTransactionModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onAdd={addTransaction} availableCategories={categories} />
      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} onLogin={handleLogin} />
    </div>
  );
};

const NavItem = ({ 
  active, 
  onClick, 
  icon, 
  label, 
  colorClass, 
  activeBg 
}: { 
  active: boolean, 
  onClick: () => void, 
  icon: React.ReactNode, 
  label: string, 
  colorClass: string,
  activeBg: string 
}) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-4 px-5 py-3 rounded-xl transition-all duration-300 group ${
      active 
        ? `${activeBg} text-white font-black shadow-lg translate-x-2` 
        : `text-[#1A4A36]/70 hover:bg-[#1A4A36]/5 font-bold`
    }`}
  >
    <div className={`transition-all duration-300 ${active ? 'scale-110 text-white' : `${colorClass} group-hover:scale-110`}`}>
      {icon}
    </div>
    <span className="text-[10px] uppercase tracking-wider leading-none pt-0.5">{label}</span>
  </button>
);

export default App;
