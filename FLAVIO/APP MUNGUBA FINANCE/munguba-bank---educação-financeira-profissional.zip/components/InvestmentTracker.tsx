
import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  TrendingUp, 
  PieChart as PieIcon, 
  Calculator, 
  RefreshCw, 
  ArrowUpRight, 
  ArrowDownRight, 
  Trash2, 
  Edit3,
  Search
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Sector } from 'recharts';
import { GoogleGenAI } from "@google/genai";
import { Investment, InvestmentType } from '../types';

interface InvestmentTrackerProps {
  investments: Investment[];
  onAdd: (inv: Omit<Investment, 'id'>) => void;
}

interface AssetSummary {
  assetName: string;
  type: InvestmentType;
  totalQuantity: number;
  totalInvested: number;
  averagePrice: number;
  currentPrice?: number;
}

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, value } = props;
  return (
    <g>
      <text x={cx} y={cy} dy={-10} textAnchor="middle" fill="#1e293b" className="font-black text-[10px] uppercase tracking-tighter">
        {payload.name}
      </text>
      <text x={cx} y={cy} dy={15} textAnchor="middle" fill={fill} className="font-black text-xs">
        {value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
      </text>
      <Sector cx={cx} cy={cy} innerRadius={innerRadius} outerRadius={outerRadius + 6} startAngle={startAngle} endAngle={endAngle} fill={fill} />
    </g>
  );
};

const InvestmentTracker: React.FC<InvestmentTrackerProps> = ({ investments, onAdd }) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isAdding, setIsAdding] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [currentPrices, setCurrentPrices] = useState<Record<string, number>>({});
  
  const [newInv, setNewInv] = useState({
    assetName: '',
    type: InvestmentType.VARIABLE_INCOME,
    price: 0,
    quantity: 0,
    date: new Date().toISOString().split('T')[0]
  });

  const assetSummaries = useMemo(() => {
    const map: Record<string, AssetSummary> = {};
    investments.forEach(inv => {
      const ticker = inv.assetName.toUpperCase().trim();
      if (!map[ticker]) {
        map[ticker] = {
          assetName: ticker,
          type: inv.type,
          totalQuantity: 0,
          totalInvested: 0,
          averagePrice: 0
        };
      }
      map[ticker].totalQuantity += inv.quantity;
      map[ticker].totalInvested += inv.value;
    });

    return Object.values(map).map(summary => ({
      ...summary,
      averagePrice: summary.totalQuantity > 0 ? summary.totalInvested / summary.totalQuantity : 0,
      currentPrice: currentPrices[summary.assetName]
    }));
  }, [investments, currentPrices]);

  const totalValue = investments.reduce((acc, i) => acc + i.value, 0);
  const totalFixed = investments.filter(i => i.type === InvestmentType.FIXED_INCOME).reduce((acc, i) => acc + i.value, 0);
  const totalVariable = investments.filter(i => i.type === InvestmentType.VARIABLE_INCOME).reduce((acc, i) => acc + i.value, 0);

  const chartData = [
    { name: 'Renda Fixa', value: totalFixed, color: '#10b981' },
    { name: 'Renda Variável', value: totalVariable, color: '#064e3b' }
  ].filter(d => d.value > 0);

  const syncPrices = async () => {
    setSyncing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const tickers = assetSummaries.map(s => s.assetName).join(', ');
      const prompt = `Retorne os preços atuais de mercado aproximados da B3 para: ${tickers}. 
      Responda APENAS JSON: {"TICKER": preco_num}.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      
      const prices = JSON.parse(response.text.replace(/```json|```/g, ''));
      setCurrentPrices(prices);
    } catch (e) {
      console.error("Erro ao sincronizar preços", e);
    } finally {
      setSyncing(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({
      assetName: newInv.assetName.toUpperCase(),
      type: newInv.type,
      price: newInv.price,
      quantity: newInv.quantity,
      value: newInv.price * newInv.quantity,
      date: newInv.date
    });
    setIsAdding(false);
    setNewInv({
      assetName: '',
      type: InvestmentType.VARIABLE_INCOME,
      price: 0,
      quantity: 0,
      date: new Date().toISOString().split('T')[0]
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <TrendingUp size={18} className="text-emerald-600" />
            <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest">Patrimônio em Ativos</h3>
          </div>
          
          <div className="p-6 bg-emerald-950 rounded-[2rem] shadow-xl relative overflow-hidden group">
            <p className="text-[9px] font-black text-emerald-400 uppercase tracking-[0.2em] mb-1">Total Consolidado</p>
            <p className="text-3xl font-black text-white tracking-tighter">
                {totalValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </p>
          </div>
        </div>

        <div className="h-[200px] w-full">
          <ResponsiveContainer>
            <PieChart>
              <Pie 
                activeIndex={activeIndex}
                activeShape={renderActiveShape}
                data={chartData} 
                innerRadius={50} 
                outerRadius={70} 
                paddingAngle={5} 
                dataKey="value"
                onMouseEnter={(_, index) => setActiveIndex(index)}
                stroke="none"
              >
                {chartData.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-100">
        <div className="flex justify-between items-center mb-6">
          <div className="flex flex-col">
            <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase font-serif italic">Gestão de Carteira</h3>
            <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Ticker Oficial B3</p>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={syncPrices}
              disabled={syncing || assetSummaries.length === 0}
              className="flex items-center gap-2 bg-slate-50 text-slate-500 font-black hover:bg-slate-100 px-4 py-2.5 rounded-xl transition-all disabled:opacity-50 text-[10px]"
            >
              <RefreshCw size={14} className={syncing ? 'animate-spin' : ''} /> 
              {syncing ? 'SYNC...' : 'ATUALIZAR PREÇOS'}
            </button>
            <button 
              onClick={() => setIsAdding(!isAdding)}
              className="flex items-center gap-2 bg-emerald-950 text-white font-black hover:bg-black px-5 py-2.5 rounded-xl transition-all text-[10px]"
            >
              {isAdding ? 'CANCELAR' : 'NOVO APORTE'}
            </button>
          </div>
        </div>

        {isAdding && (
          <form onSubmit={handleSubmit} className="mb-6 p-5 bg-emerald-50/50 rounded-2xl border border-emerald-100 grid grid-cols-2 md:grid-cols-5 gap-4 items-end animate-in slide-in-from-top-2 duration-300">
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase">Ticker</label>
              <input required className="w-full p-2.5 rounded-xl border border-slate-200 uppercase font-black text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                value={newInv.assetName} onChange={e => setNewInv({...newInv, assetName: e.target.value})} placeholder="PETR4" />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase">Preço Unit.</label>
              <input type="number" step="0.01" required className="w-full p-2.5 rounded-xl border border-slate-200 font-black text-xs outline-none"
                value={newInv.price || ''} onChange={e => setNewInv({...newInv, price: parseFloat(e.target.value)})} placeholder="0,00" />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase">Quantidade</label>
              <input type="number" required className="w-full p-2.5 rounded-xl border border-slate-200 font-black text-xs outline-none"
                value={newInv.quantity || ''} onChange={e => setNewInv({...newInv, quantity: parseInt(e.target.value)})} placeholder="0" />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase">Tipo</label>
              <select className="w-full p-2.5 rounded-xl border border-slate-200 font-black text-[10px] outline-none"
                value={newInv.type} onChange={e => setNewInv({...newInv, type: e.target.value as InvestmentType})}>
                <option value={InvestmentType.VARIABLE_INCOME}>VARIÁVEL</option>
                <option value={InvestmentType.FIXED_INCOME}>FIXA</option>
              </select>
            </div>
            <button type="submit" className="bg-emerald-600 text-white p-2.5 rounded-xl font-black text-[10px] uppercase hover:bg-emerald-700 transition-all">ADICIONAR</button>
          </form>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-slate-400 text-[9px] font-black uppercase tracking-widest border-b border-slate-50">
                <th className="pb-4 px-2">Ticker</th>
                <th className="pb-4 px-2">Qtd.</th>
                <th className="pb-4 px-2">P. Médio</th>
                <th className="pb-4 px-2 text-center">Atual</th>
                <th className="pb-4 px-2 text-center">Var.</th>
                <th className="pb-4 px-2 text-right">Total</th>
                <th className="pb-4 px-2 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {assetSummaries.map(asset => {
                const yieldPct = asset.currentPrice ? ((asset.currentPrice - asset.averagePrice) / asset.averagePrice) * 100 : null;
                const isPositive = yieldPct !== null && yieldPct >= 0;
                
                return (
                  <tr key={asset.assetName} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-5 px-2">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-slate-900 text-emerald-400 rounded-lg flex items-center justify-center font-black text-[9px]">
                          {asset.assetName.slice(0, 3)}
                        </div>
                        <span className="font-black text-slate-800 text-sm tracking-tighter">{asset.assetName}</span>
                      </div>
                    </td>
                    <td className="py-5 px-2">
                      <span className="font-bold text-slate-700 text-xs">{asset.totalQuantity}</span>
                    </td>
                    <td className="py-5 px-2">
                      <span className="font-bold text-slate-800 text-xs">{asset.averagePrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                    </td>
                    <td className="py-5 px-2 text-center">
                      <span className="font-black text-slate-900 text-xs">
                        {asset.currentPrice ? asset.currentPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : '-'}
                      </span>
                    </td>
                    <td className="py-5 px-2 text-center">
                      {yieldPct !== null ? (
                        <div className={`inline-flex items-center gap-0.5 px-2 py-1 rounded-lg font-black text-[9px] ${
                          isPositive ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'
                        }`}>
                          {isPositive ? <ArrowUpRight size={10}/> : <ArrowDownRight size={10}/>}
                          {yieldPct.toFixed(2)}%
                        </div>
                      ) : <span className="text-slate-200 text-xs">-</span>}
                    </td>
                    <td className="py-5 px-2 text-right">
                      <span className="font-black text-slate-900 text-sm tracking-tighter">
                        {asset.totalInvested.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                    </td>
                    <td className="py-5 px-2 text-right">
                      <div className="flex justify-end gap-1">
                        <button className="p-1.5 text-slate-300 hover:text-emerald-600 transition-colors"><Edit3 size={14} /></button>
                        <button className="p-1.5 text-slate-300 hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {assetSummaries.length === 0 && (
            <div className="py-12 text-center">
              <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Nenhum ativo na carteira</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default InvestmentTracker;
