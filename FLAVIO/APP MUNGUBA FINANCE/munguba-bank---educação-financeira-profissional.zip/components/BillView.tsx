
import React, { useState, useEffect } from 'react';
import { 
  ReceiptText, 
  Search, 
  Calendar, 
  Barcode, 
  Copy, 
  CheckCircle2, 
  AlertCircle,
  Clock,
  ArrowRight,
  RefreshCw,
  Bell
} from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import { Bill, UserProfile } from '../types';

interface BillViewProps {
  user: UserProfile | null;
}

const BillView: React.FC<BillViewProps> = ({ user }) => {
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const fetchBillsByCpf = async () => {
    if (!user?.cpf) return;
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Simule a busca de boletos registrados no CPF ${user.cpf} no DDA (Débito Direto Autorizado) do Brasil. 
        Gere 3 boletos realistas de contas comuns (Energia, Internet, Cartão de Crédito). 
        Um deles deve ter vencimento para HOJE (${new Date().toISOString().split('T')[0]}).
        Retorne APENAS um JSON seguindo este esquema:
        {"bills": [{"id": "uuid", "issuer": "nome emissor", "dueDate": "YYYY-MM-DD", "value": 0.0, "status": "Pendente", "barcode": "string"}]}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              bills: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    issuer: { type: Type.STRING },
                    dueDate: { type: Type.STRING },
                    value: { type: Type.NUMBER },
                    status: { type: Type.STRING, enum: ['Pendente', 'Pago', 'Atrasado'] },
                    barcode: { type: Type.STRING }
                  },
                  required: ['id', 'issuer', 'dueDate', 'value', 'status', 'barcode']
                }
              }
            }
          }
        },
      });

      const data = JSON.parse(response.text);
      setBills(data.bills || []);
    } catch (e) {
      console.error("Erro ao buscar boletos:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.cpf) {
      fetchBillsByCpf();
    }
  }, [user?.cpf]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const isDueToday = (dateStr: string) => {
    const today = new Date().toISOString().split('T')[0];
    return dateStr === today;
  };

  if (!user) {
    return (
      <div className="bg-white p-16 rounded-[3rem] border border-slate-100 shadow-sm text-center space-y-6">
        <div className="bg-slate-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto text-slate-300">
          <ReceiptText size={40} />
        </div>
        <div className="space-y-2">
          <h3 className="text-2xl font-black text-slate-800 tracking-tight">Identificação Necessária</h3>
          <p className="text-slate-500 max-w-sm mx-auto font-medium">Faça login com seu CPF para que possamos monitorar seus boletos emitidos automaticamente.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      {/* Header e Busca */}
      <div className="bg-emerald-950 p-10 rounded-[3rem] text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 opacity-10 p-10"><Barcode size={150} /></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="space-y-2">
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-emerald-400">Monitoramento DDA</span>
            <h2 className="text-4xl font-black tracking-tighter italic font-serif">Seus Boletos Digitais</h2>
            <p className="text-emerald-100/60 font-medium">Buscando contas emitidas para <span className="text-white font-bold">{user.cpf}</span></p>
          </div>
          <button 
            onClick={fetchBillsByCpf}
            disabled={loading}
            className="bg-emerald-500 text-emerald-950 hover:bg-emerald-400 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all flex items-center gap-3 disabled:opacity-50"
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
            {loading ? 'Sincronizando...' : 'Atualizar Busca'}
          </button>
        </div>
      </div>

      {/* Alerta de Vencimento Hoje */}
      {bills.some(b => isDueToday(b.dueDate)) && (
        <div className="bg-orange-50 border-2 border-orange-200 p-6 rounded-[2rem] flex items-center gap-6 animate-in zoom-in duration-500 shadow-lg shadow-orange-900/5">
          <div className="bg-orange-500 p-4 rounded-2xl text-white animate-bounce">
            <Bell size={24} />
          </div>
          <div className="flex-1">
            <h4 className="text-lg font-black text-orange-900">Atenção ao Vencimento!</h4>
            <p className="text-orange-800 font-medium">Você possui contas que vencem <span className="font-black underline">HOJE</span>. Evite juros e multas realizando o pagamento agora.</p>
          </div>
          <div className="hidden md:block">
             <AlertCircle size={40} className="text-orange-200" />
          </div>
        </div>
      )}

      {/* Listagem de Boletos */}
      <div className="grid grid-cols-1 gap-6">
        {loading ? (
          [1,2,3].map(i => <div key={i} className="h-32 bg-slate-100 rounded-[2.5rem] animate-pulse" />)
        ) : bills.length > 0 ? (
          bills.map(bill => (
            <div 
              key={bill.id} 
              className={`bg-white p-8 rounded-[2.5rem] border-2 transition-all flex flex-col md:flex-row md:items-center justify-between gap-8 group ${
                isDueToday(bill.dueDate) ? 'border-orange-200 bg-orange-50/10' : 'border-slate-50 hover:border-emerald-100'
              }`}
            >
              <div className="flex items-center gap-6">
                <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center shrink-0 ${
                  isDueToday(bill.dueDate) ? 'bg-orange-100 text-orange-600' : 'bg-slate-100 text-slate-400'
                }`}>
                  <ReceiptText size={28} />
                </div>
                <div>
                  <h4 className="text-xl font-black text-slate-800 tracking-tight">{bill.issuer}</h4>
                  <div className="flex items-center gap-4 mt-1">
                    <div className="flex items-center gap-1.5 text-slate-400 font-bold text-[10px] uppercase">
                      <Calendar size={12} /> Vence em {new Date(bill.dueDate).toLocaleDateString('pt-BR')}
                    </div>
                    {isDueToday(bill.dueDate) && (
                      <span className="bg-orange-100 text-orange-600 px-2 py-0.5 rounded text-[9px] font-black uppercase">Vence Hoje</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex flex-col md:items-end">
                <span className="text-2xl font-black text-slate-900 tracking-tighter">
                  {bill.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </span>
                <span className={`text-[9px] font-black uppercase mt-1 ${
                  bill.status === 'Pendente' ? 'text-blue-500' : 'text-emerald-500'
                }`}>
                  Status: {bill.status}
                </span>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3">
                <button 
                  onClick={() => copyToClipboard(bill.barcode, bill.id)}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 bg-slate-900 text-white px-6 py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-black transition-all"
                >
                  {copiedId === bill.id ? <CheckCircle2 size={16} /> : <Barcode size={16} />}
                  {copiedId === bill.id ? 'COPIADO' : 'COPIAR CÓDIGO'}
                </button>
                <button className="w-full sm:w-auto flex items-center justify-center gap-2 bg-white border border-slate-200 text-slate-800 px-6 py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-50 transition-all">
                  Pagar Agora <ArrowRight size={16} />
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-20 space-y-4 bg-white rounded-[3rem] border border-slate-100">
            <Search size={48} className="mx-auto text-slate-200" />
            <p className="text-slate-400 font-black uppercase text-xs tracking-widest">Nenhum boleto encontrado para este CPF.</p>
          </div>
        )}
      </div>

      {/* Dica do Mentor */}
      <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col md:flex-row gap-8 items-center">
        <div className="bg-emerald-100 p-5 rounded-3xl text-emerald-600">
          <Clock size={32} />
        </div>
        <div className="space-y-2">
          <h4 className="text-xl font-black text-slate-800 italic font-serif">Regra de Ouro do Pagamento</h4>
          <p className="text-slate-500 leading-relaxed font-medium">
            Sempre tente antecipar seus boletos em 2 dias úteis. Isso garante que instabilidades bancárias não gerem atrasos. Organização é o segredo para nunca pagar juros desnecessários.
          </p>
        </div>
      </div>
    </div>
  );
};

export default BillView;
