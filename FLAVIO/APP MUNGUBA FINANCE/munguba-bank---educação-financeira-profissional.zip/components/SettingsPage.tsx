
import React, { useState } from 'react';
import { Plus, Trash2, Tag, ArrowUpCircle, ArrowDownCircle, PieChart } from 'lucide-react';
import { TransactionType } from '../types';

interface SettingsPageProps {
  categories: Record<TransactionType, string[]>;
  onUpdateCategories: (newCats: Record<TransactionType, string[]>) => void;
}

const SettingsPage: React.FC<SettingsPageProps> = ({ categories, onUpdateCategories }) => {
  const [newCategoryName, setNewCategoryName] = useState('');
  const [targetType, setTargetType] = useState<TransactionType>(TransactionType.VARIABLE);

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;

    const currentCats = [...categories[targetType]];
    if (currentCats.includes(newCategoryName.trim())) return;

    const updated = {
      ...categories,
      [targetType]: [...currentCats, newCategoryName.trim()]
    };
    onUpdateCategories(updated);
    setNewCategoryName('');
  };

  const handleRemoveCategory = (type: TransactionType, name: string) => {
    const updated = {
      ...categories,
      [type]: categories[type].filter(cat => cat !== name)
    };
    onUpdateCategories(updated);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <h3 className="text-lg font-bold text-slate-800 mb-2 flex items-center gap-2">
          <Tag className="text-emerald-500" size={20} />
          Personalizar Categorias
        </h3>
        <p className="text-slate-500 text-sm mb-6">Adicione ou remova categorias para adaptar o Munguba Bank à sua realidade financeira.</p>

        <form onSubmit={handleAddCategory} className="flex flex-col md:flex-row gap-4 mb-8 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div className="flex-1 space-y-1">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Nome da Categoria</label>
            <input 
              type="text"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              placeholder="Ex: Pets, Assinaturas, Freelance..."
              className="w-full p-2.5 rounded-lg border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none"
            />
          </div>
          <div className="w-full md:w-48 space-y-1">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Tipo de Fluxo</label>
            <select 
              value={targetType}
              onChange={(e) => setTargetType(e.target.value as TransactionType)}
              className="w-full p-2.5 rounded-lg border border-slate-200 font-bold text-slate-700 outline-none"
            >
              <option value={TransactionType.INCOME}>Receita</option>
              <option value={TransactionType.FIXED}>Custo Fixo</option>
              <option value={TransactionType.VARIABLE}>Custo Variável</option>
            </select>
          </div>
          <button 
            type="submit"
            className="md:self-end bg-emerald-600 text-white px-6 py-2.5 rounded-lg font-bold hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
          >
            <Plus size={18} />
            Adicionar
          </button>
        </form>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <CategoryList 
            title="Receitas" 
            icon={<ArrowUpCircle className="text-emerald-500" size={16} />} 
            items={categories[TransactionType.INCOME]} 
            onRemove={(name) => handleRemoveCategory(TransactionType.INCOME, name)}
          />
          <CategoryList 
            title="Custos Fixos" 
            icon={<ArrowDownCircle className="text-red-500" size={16} />} 
            items={categories[TransactionType.FIXED]} 
            onRemove={(name) => handleRemoveCategory(TransactionType.FIXED, name)}
          />
          <CategoryList 
            title="Custos Variáveis" 
            icon={<PieChart className="text-orange-500" size={16} />} 
            items={categories[TransactionType.VARIABLE]} 
            onRemove={(name) => handleRemoveCategory(TransactionType.VARIABLE, name)}
          />
        </div>
      </div>
    </div>
  );
};

const CategoryList = ({ title, icon, items, onRemove }: { title: string, icon: React.ReactNode, items: string[], onRemove: (name: string) => void }) => (
  <div className="space-y-3">
    <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
      {icon}
      <h4 className="font-bold text-slate-700 text-sm uppercase tracking-tight">{title}</h4>
    </div>
    <div className="flex flex-wrap gap-2">
      {items.map(item => (
        <div key={item} className="group flex items-center gap-2 bg-slate-100 hover:bg-emerald-50 text-slate-600 hover:text-emerald-700 px-3 py-1.5 rounded-full text-xs font-medium transition-all">
          {item}
          <button 
            onClick={() => onRemove(item)}
            className="text-slate-300 hover:text-red-500 transition-colors"
          >
            <Trash2 size={12} />
          </button>
        </div>
      ))}
      {items.length === 0 && <span className="text-slate-400 text-[10px] italic">Nenhuma categoria</span>}
    </div>
  </div>
);

export default SettingsPage;
