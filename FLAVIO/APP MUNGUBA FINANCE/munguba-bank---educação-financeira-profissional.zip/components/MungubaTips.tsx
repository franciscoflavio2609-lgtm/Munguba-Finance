
import React, { useEffect, useState, useCallback } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { Sparkles, Leaf, TrendingUp, Quote, RefreshCw, ChevronRight, ChevronLeft, Lightbulb, Target, ShieldCheck } from 'lucide-react';

interface WeeklyTips {
  financialTip: string;
  investmentInsight: string;
  motivationalQuote: string;
  author: string;
}

interface MungubaTipsProps {
  variant?: 'full' | 'compact';
}

const MungubaTips: React.FC<MungubaTipsProps> = ({ variant = 'full' }) => {
  const [tips, setTips] = useState<WeeklyTips | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTipIndex, setActiveTipIndex] = useState(0);

  const fetchWeeklyTips = useCallback(async () => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const now = new Date();
      const weekOfYear = Math.ceil(now.getDate() / 7) + now.getMonth() * 4;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Gere as "Dicas Munguba" exclusivas para a semana atual (ID: ${weekOfYear}). 
        O conteúdo deve ser focado rigorosamente em:
        1. REGRAS DO ORÇAMENTO: A importância de seguir o plano (ex: 50/25/25).
        2. INVESTIMENTOS: Por que investir é a única forma de proteger o futuro.
        3. DISCIPLINA: Frase motivacional para manter o controle de gastos e aportes.
        
        Responda APENAS em JSON seguindo este esquema: 
        {"financialTip": "dica sobre regras de orçamento e controle", "investmentInsight": "insight sobre a importância de investir", "motivationalQuote": "frase de impacto sobre disciplina financeira", "author": "Munguba Bank"}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              financialTip: { type: Type.STRING },
              investmentInsight: { type: Type.STRING },
              motivationalQuote: { type: Type.STRING },
              author: { type: Type.STRING }
            },
            required: ['financialTip', 'investmentInsight', 'motivationalQuote', 'author']
          }
        },
      });

      const data = JSON.parse(response.text);
      setTips(data);
    } catch (e) {
      console.error("Erro ao buscar Dicas Munguba:", e);
      setTips({
        financialTip: "A regra 50/25/25 é o seu escudo. Não deixe os gastos variáveis invadirem o espaço do seu futuro.",
        investmentInsight: "Investir não é opcional, é a garantia de que seu 'eu' do futuro terá dignidade e paz.",
        motivationalQuote: "A disciplina de anotar seus gastos hoje constrói a liberdade de não precisar olhar preços amanhã.",
        author: "Munguba Bank"
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWeeklyTips();
  }, [fetchWeeklyTips]);

  const tipItems = tips ? [
    { label: 'Regras', text: tips.financialTip, icon: <ShieldCheck size={14} className="text-emerald-500" /> },
    { label: 'Investir', text: tips.investmentInsight, icon: <TrendingUp size={14} className="text-blue-500" /> },
    { label: 'Disciplina', text: tips.motivationalQuote, icon: <Target size={14} className="text-purple-500" /> }
  ] : [];

  if (variant === 'compact') {
    return (
      <div className="hidden lg:flex items-center gap-4 bg-white border-2 border-emerald-500/10 px-5 py-3 rounded-2xl shadow-xl shadow-emerald-900/5 animate-in fade-in slide-in-from-right-8 duration-700 min-w-[380px] max-w-[550px] relative group hover:border-emerald-500/30 transition-all">
        <div className="absolute -top-2 -left-2">
            <div className="bg-emerald-600 p-2 rounded-xl text-white shadow-lg">
                <Lightbulb size={16} className={loading ? 'animate-pulse' : ''} />
            </div>
        </div>
        
        <div className="flex-1 pl-4 overflow-hidden">
          {loading ? (
            <div className="space-y-2">
              <div className="h-2.5 bg-slate-100 rounded-full w-24 animate-pulse"></div>
              <div className="h-2.5 bg-slate-50 rounded-full w-full animate-pulse"></div>
            </div>
          ) : (
            <div className="flex flex-col">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[9px] font-black text-emerald-800/60 uppercase tracking-widest leading-none">
                  Dicas Munguba • {tipItems[activeTipIndex]?.label}
                </span>
                {tipItems[activeTipIndex]?.icon}
              </div>
              <p className="text-[11px] text-[#1A4A36] font-bold leading-tight italic line-clamp-2">
                "{tipItems[activeTipIndex]?.text}"
              </p>
            </div>
          )}
        </div>

        {!loading && (
          <div className="flex flex-col gap-1 ml-2 shrink-0 border-l border-emerald-100 pl-2">
            <button 
              onClick={() => setActiveTipIndex(prev => (prev === 2 ? 0 : prev + 1))}
              className="p-1 hover:bg-emerald-50 rounded-lg transition-colors text-emerald-700"
              title="Próxima Dica"
            >
              <ChevronRight size={16} />
            </button>
            <button 
              onClick={fetchWeeklyTips}
              className="p-1 hover:bg-emerald-50 rounded-lg transition-colors text-emerald-400"
              title="Atualizar"
            >
              <RefreshCw size={12} className={loading ? 'animate-spin' : ''} />
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-[#1A4A36] to-[#0A2A1F] p-8 rounded-[3rem] text-white shadow-xl relative overflow-hidden group">
      <div className="absolute -top-10 -right-10 opacity-10 group-hover:rotate-12 transition-transform duration-1000">
        <Leaf size={180} />
      </div>
      <div className="relative z-10 space-y-8">
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Sparkles className="text-emerald-400" size={18} />
              <h3 className="text-[11px] font-black uppercase tracking-[0.3em] text-emerald-300">Dicas Munguba</h3>
            </div>
            <h4 className="text-2xl font-black font-serif italic tracking-tight">Sabedoria Semanal</h4>
          </div>
          <button 
            onClick={fetchWeeklyTips} 
            disabled={loading}
            className="p-3 bg-white/10 hover:bg-white/20 rounded-2xl transition-all disabled:opacity-50"
          >
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1,2,3].map(i => <div key={i} className="h-32 bg-white/5 rounded-[2rem] animate-pulse" />)}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-3 bg-white/5 p-6 rounded-[2rem] border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all">
              <div className="text-emerald-400"><ShieldCheck size={24} /></div>
              <p className="text-[10px] font-black uppercase tracking-widest text-emerald-300/60">Regras de Ouro</p>
              <p className="text-sm font-medium leading-relaxed italic">"{tips?.financialTip}"</p>
            </div>
            <div className="space-y-3 bg-white/5 p-6 rounded-[2rem] border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all">
              <div className="text-blue-400"><TrendingUp size={24} /></div>
              <p className="text-[10px] font-black uppercase tracking-widest text-blue-300/60">Importância de Investir</p>
              <p className="text-sm font-medium leading-relaxed italic">"{tips?.investmentInsight}"</p>
            </div>
            <div className="space-y-3 bg-white/5 p-6 rounded-[2rem] border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all">
              <div className="text-purple-400"><Target size={24} /></div>
              <p className="text-[10px] font-black uppercase tracking-widest text-purple-300/60">Disciplina Diária</p>
              <p className="text-sm font-bold leading-relaxed italic">"{tips?.motivationalQuote}"</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MungubaTips;
