
import React, { useState } from 'react';
import { X, Lock, User, ArrowRight, CreditCard } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (name: string, cpf: string) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLogin }) => {
  const [name, setName] = useState('');
  const [cpf, setCpf] = useState('');
  const [password, setPassword] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && cpf && password) {
      onLogin(name, cpf);
      onClose();
    }
  };

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Máscara simples para CPF
    let value = e.target.value.replace(/\D/g, '');
    if (value.length <= 11) {
      value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
      setCpf(value);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-emerald-950/60 backdrop-blur-md">
      <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in duration-300 border border-emerald-100">
        <div className="p-8 pb-4 flex justify-between items-center">
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-emerald-950 tracking-tighter uppercase italic font-serif">Acesso Restrito</h3>
            <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Portal do Mentorando Munguba</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 pt-4 space-y-5">
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Seu Nome</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-600" size={18} />
                <input
                  type="text"
                  required
                  placeholder="Como deseja ser chamado?"
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-slate-800 transition-all"
                  value={name}
                  onChange={e => setName(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Seu CPF (Para busca de boletos)</label>
              <div className="relative">
                <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-600" size={18} />
                <input
                  type="text"
                  required
                  placeholder="000.000.000-00"
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-slate-800 transition-all"
                  value={cpf}
                  onChange={handleCpfChange}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Senha Mestra</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-600" size={18} />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-slate-800 transition-all"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-5 bg-[#1A4A36] text-[#ADEBB3] font-black rounded-2xl hover:bg-black hover:text-white shadow-xl shadow-emerald-900/10 transition-all flex items-center justify-center gap-3 active:scale-95 uppercase tracking-widest text-xs"
          >
            Entrar no Ecossistema
            <ArrowRight size={18} />
          </button>

          <p className="text-center text-[9px] font-bold text-slate-400 uppercase leading-relaxed px-4">
            Ao entrar você concorda com os termos de consultoria estratégica do Munguba Bank.
          </p>
        </form>
      </div>
    </div>
  );
};

export default AuthModal;
