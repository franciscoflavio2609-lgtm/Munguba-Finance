
import React, { useState } from 'react';
import { 
  ResponsiveContainer, Cell, PieChart, Pie, Tooltip, Sector, BarChart, Bar, XAxis, YAxis, CartesianGrid
} from 'recharts';
import { 
  ArrowUpCircle, Wallet, History, TrendingUp, CheckCircle2, Home, ShoppingBag, Target, Layers, Sparkles
} from 'lucide-react';
import { Transaction, DashboardStats, TransactionType, Investment } from '../types';
import TransactionList from './TransactionList';
import MarketInsights from './MarketInsights';

interface DashboardProps {
  stats: DashboardStats;
  transactions: Transaction[];
  investments: Investment[];
}

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, value } = props;
  return (
    <g>
      <text x={cx} y={cy} dy={-10} textAnchor="middle" fill="#1e293b" className="font-black text-[10px] md:text-xs uppercase tracking-tighter">
        {payload.name}
      </text>
      <text x={cx} y={cy} dy={15} textAnchor="middle" fill={fill} className="font-black text-xs md:text-sm">
        {value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius + 6}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
    </g>
  );
};

const Dashboard: React.FC<DashboardProps> = ({ stats, transactions, investments }) => {
  const [healthIndex, setHealthIndex] = useState(0);
  const [assetIndex, setAssetIndex] = useState(0);
  
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const currentMonthTransactions = transactions.filter(t => {
    const d = new Date(t.date);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });

  const mIncome = currentMonthTransactions.filter(t => t.type === TransactionType.INCOME).reduce((acc, t) => acc + t.value, 0);
  const mFixed = currentMonthTransactions.filter(t => t.type === TransactionType.FIXED).reduce((acc, t) => acc + t.value, 0);
  const mVariable = currentMonthTransactions.filter(t => t.type === TransactionType.VARIABLE).reduce((acc, t) => acc + t.value, 0);
  const mBalance = mIncome - (mFixed + mVariable);
  
  const totalFixedHistory = transactions.filter(t => t.type === TransactionType.FIXED).reduce((acc, t) => acc + t.value, 0);
  const totalVariableHistory = transactions.filter(t => t.type === TransactionType.VARIABLE).reduce((acc, t) => acc + t.value, 0);
  const totalInvestedConsolidated = investments.reduce((acc, i) => acc + i.value, 0);
  
  const mInvestedPct = mIncome > 0 ? (Math.max(0, mBalance) / mIncome) * 100 : 0;
  const metaAtingida = mInvestedPct >= 25;

  // Dados para o Gráfico de Saúde Mensal
  const healthData = [
    { name: 'Custos Fixos', value: mFixed, fill: '#ef4444' },
    { name: 'Custos Variáveis', value: mVariable, fill: '#f97316' },
    { name: 'Investimentos', value: Math.max(0, mBalance), fill: '#3b82f6' },
  ];

  // Agrupamento de Ativos para o Gráfico de Patrimônio
  const assetData = investments.reduce((acc: any[], inv) => {
    const existing = acc.find(a => a.name === inv.assetName);
    if (existing) {
      existing.value += inv.value;
    } else {
      acc.push({ name: inv.assetName, value: inv.value });
    }
    return acc;
  }, []);

  const COLORS = ['#10b981', '#064e3b', '#3b82f6', '#1e3a8a', '#6366f1', '#a855f7'];

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      
      {/* 1. SAÚDE MENSAL (GRÁFICO INTERATIVO) */}
      <section className="bg-white p-8 rounded-[3rem] shadow-sm border border-slate-100 overflow-hidden">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="w-full lg:w-1/2 h-[300px] relative">
            <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 text-center">Saúde Financeira Mensal</h3>
            <ResponsiveContainer>
              <PieChart>
                <Pie 
                  activeIndex={healthIndex}
                  activeShape={renderActiveShape}
                  data={healthData} 
                  innerRadius={80} 
                  outerRadius={100} 
                  paddingAngle={5} 
                  dataKey="value" 
                  stroke="none"
                  onMouseEnter={(_, index) => setHealthIndex(index)}
                >
                  {healthData.map((e, i) => <Cell key={i} fill={e.fill} />)}
                </Pie>
                <Tooltip 
                  formatter={(v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="flex-1 space-y-6">
            <h4 className="text-3xl font-black text-slate-800 italic font-serif tracking-tight">Equilíbrio Financeiro</h4>
            <p className="text-slate-500 leading-relaxed font-medium">
              A saúde do seu bolso depende do controle dos custos. A meta é que os <span className="text-blue-600 font-bold">Investimentos</span> representem pelo menos 25% da sua receita mensal.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex items-center gap-3 p-4 bg-red-50 rounded-2xl border border-red-100">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <span className="text-[10px] font-black text-red-900 uppercase">Custos Fixos</span>
              </div>
              <div className="flex items-center gap-3 p-4 bg-orange-50 rounded-2xl border border-orange-100">
                <div className="w-3 h-3 rounded-full bg-orange-500" />
                <span className="text-[10px] font-black text-orange-900 uppercase">C. Variáveis</span>
              </div>
              <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-2xl border border-blue-100">
                <div className="w-3 h-3 rounded-full bg-blue-500" />
                <span className="text-[10px] font-black text-blue-900 uppercase">Investido</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MENSAGEM DE CONGRATULAÇÃO */}
      {metaAtingida && (
        <div className="bg-emerald-600 p-8 rounded-[2.5rem] text-white shadow-xl shadow-emerald-200 flex flex-col md:flex-row items-center justify-between gap-6 animate-in zoom-in duration-500">
          <div className="flex items-center gap-6">
            <div className="bg-white/20 p-4 rounded-3xl backdrop-blur-md">
              <CheckCircle2 size={40} />
            </div>
            <div>
              <h3 className="text-2xl font-black font-serif italic">Meta Atingida!</h3>
              <p className="text-emerald-100 font-medium">Você poupou {mInvestedPct.toFixed(1)}% da sua renda. O caminho da liberdade é feito de constância.</p>
            </div>
          </div>
          <div className="text-center bg-white/10 px-8 py-4 rounded-2xl backdrop-blur-sm border border-white/20">
            <span className="text-[10px] font-black text-emerald-200 uppercase tracking-widest block mb-1">Total em Ativos</span>
            <span className="text-2xl font-black">{(totalInvestedConsolidated).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
          </div>
        </div>
      )}

      {/* 2. RECEITA, SALDO E PATRIMÔNIO (MÉTRICAS) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-7 rounded-[2rem] border border-slate-100 shadow-sm group hover:border-emerald-200 transition-all">
          <div className="bg-emerald-100 w-12 h-12 rounded-xl flex items-center justify-center text-emerald-600 mb-4 group-hover:scale-110 transition-transform"><ArrowUpCircle size={24}/></div>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Receita do Mês</span>
          <p className="text-3xl font-black text-slate-800 tracking-tighter">{mIncome.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
        </div>
        <div className="bg-white p-7 rounded-[2rem] border border-slate-100 shadow-sm group hover:border-blue-200 transition-all">
          <div className="bg-blue-100 w-12 h-12 rounded-xl flex items-center justify-center text-blue-600 mb-4 group-hover:scale-110 transition-transform"><Wallet size={24}/></div>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Saldo Líquido</span>
          <p className="text-3xl font-black text-slate-800 tracking-tighter">{mBalance.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
        </div>
        <div className="bg-slate-900 p-7 rounded-[2rem] shadow-xl group hover:bg-black transition-all">
          <div className="bg-emerald-500 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4 group-hover:rotate-12 transition-transform"><TrendingUp size={24}/></div>
          <span className="text-[10px] font-black text-emerald-300 uppercase tracking-widest">Patrimônio Consolidado</span>
          <p className="text-3xl font-black text-white tracking-tighter">{totalInvestedConsolidated.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
        </div>
      </div>

      {/* 3. PATRIMÔNIO CONSOLIDADO (GRÁFICO DE ATIVOS) - ACIMA DA CENTRAL DE ALERTAS */}
      <section className="bg-white p-8 rounded-[3rem] shadow-sm border border-slate-100 overflow-hidden">
        <div className="flex items-center gap-3 mb-8">
          <div className="bg-slate-100 p-3 rounded-2xl text-slate-900">
            <Layers size={24} />
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Composição do Patrimônio</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Diferenciação por ativos e valores investidos</p>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row items-center gap-10">
          <div className="w-full lg:w-1/2 h-[350px]">
            <ResponsiveContainer>
              <PieChart>
                <Pie 
                  activeIndex={assetIndex}
                  activeShape={renderActiveShape}
                  data={assetData} 
                  innerRadius={85} 
                  outerRadius={115} 
                  paddingAngle={4} 
                  dataKey="value" 
                  stroke="none"
                  onMouseEnter={(_, index) => setAssetIndex(index)}
                >
                  {assetData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip 
                  formatter={(v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  contentStyle={{ borderRadius: '1.5rem', border: 'none', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="flex-1 w-full space-y-4">
             <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-2">Resumo da Carteira</span>
                <div className="space-y-3">
                  {assetData.map((asset, i) => (
                    <div key={asset.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                        <span className="text-xs font-bold text-slate-700">{asset.name}</span>
                      </div>
                      <span className="text-xs font-black text-slate-900">{asset.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                    </div>
                  ))}
                  {assetData.length === 0 && <p className="text-xs text-slate-400 italic">Nenhum investimento registrado.</p>}
                </div>
                <div className="mt-6 pt-4 border-t border-slate-200 flex justify-between items-center">
                  <span className="text-sm font-black text-slate-800">Total Investido</span>
                  <span className="text-lg font-black text-emerald-600">{totalInvestedConsolidated.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                </div>
             </div>
          </div>
        </div>
      </section>

      {/* 4. ALERTAS E INSIGHTS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <MarketInsights />
        </div>

        {/* 5. CUSTOS COMPILADOS (HISTÓRICO) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col items-center">
              <div className="flex items-center gap-2 mb-6">
                <Home size={16} className="text-red-500" />
                <h3 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Custos Fixos Totais</h3>
              </div>
              <div className="h-[180px] w-full relative">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={[{value: totalFixedHistory}]} innerRadius={55} outerRadius={70} dataKey="value" stroke="none">
                      <Cell fill="#ef4444" />
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
                  <span className="text-lg font-black text-slate-800">{totalFixedHistory.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                </div>
              </div>
              <p className="text-[9px] font-bold text-slate-400 uppercase mt-4">Total histórico acumulado</p>
            </div>

            <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col items-center">
              <div className="flex items-center gap-2 mb-6">
                <ShoppingBag size={16} className="text-orange-500" />
                <h3 className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Custos Variáveis Totais</h3>
              </div>
              <div className="h-[180px] w-full relative">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={[{value: totalVariableHistory}]} innerRadius={55} outerRadius={70} dataKey="value" stroke="none">
                      <Cell fill="#f97316" />
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
                  <span className="text-lg font-black text-slate-800">{totalVariableHistory.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
                </div>
              </div>
              <p className="text-[9px] font-bold text-slate-400 uppercase mt-4">Gestão de estilo de vida</p>
            </div>
          </div>

          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
             <div className="flex items-center gap-2 mb-6">
                <History size={18} className="text-emerald-600" />
                <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest">Fluxo de Caixa Recente</h3>
             </div>
             <TransactionList transactions={transactions.slice(-5)} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
