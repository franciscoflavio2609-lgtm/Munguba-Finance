
import React, { useEffect, useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { RefreshCw, Bell, TrendingUp, Fuel, ShoppingBasket, DollarSign, ExternalLink } from 'lucide-react';

interface NotificationItem {
  topic: string;
  message: string;
  type: 'juros' | 'combustivel' | 'alimentos' | 'geral';
}

const MarketInsights: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [sources, setSources] = useState<{title: string, uri: string}[]>([]);

  const fetchInsights = async () => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: 'Busque notícias econômicas rápidas do Brasil sobre Selic, gasolina e dólar. Retorne JSON com 4 itens.',
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              notifications: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    topic: { type: Type.STRING },
                    message: { type: Type.STRING },
                    type: { type: Type.STRING, enum: ['juros', 'combustivel', 'alimentos', 'geral'] }
                  },
                  required: ['topic', 'message', 'type']
                }
              }
            },
            required: ['notifications']
          }
        },
      });

      const data = JSON.parse(response.text);
      setNotifications(data.notifications || []);
      
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        setSources(chunks.filter((c: any) => c.web).map((c: any) => ({
          title: c.web.title,
          uri: c.web.uri
        })).slice(0, 2));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchInsights(); }, []);

  const getIcon = (type: string) => {
    switch(type) {
      case 'juros': return <TrendingUp size={14} className="text-blue-500" />;
      case 'combustivel': return <Fuel size={14} className="text-orange-500" />;
      case 'alimentos': return <ShoppingBasket size={14} className="text-emerald-500" />;
      default: return <DollarSign size={14} className="text-purple-500" />;
    }
  };

  return (
    <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 h-full flex flex-col shadow-sm">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-2">
          <div className="bg-slate-900 p-2 rounded-xl">
            <Bell className="text-white w-4 h-4" />
          </div>
          <h3 className="text-[11px] font-black text-slate-800 uppercase tracking-widest">Central de Alertas</h3>
        </div>
        <button onClick={fetchInsights} disabled={loading} className="text-slate-400 hover:text-emerald-600 transition-all">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      <div className="space-y-4 flex-1">
        {loading ? (
          [1, 2, 3, 4].map(i => <div key={i} className="h-16 bg-slate-50 rounded-2xl animate-pulse" />)
        ) : (
          notifications.map((note, idx) => (
            <div key={idx} className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100 hover:bg-white hover:shadow-md transition-all cursor-default">
              <div className="flex gap-3">
                <div className="mt-1 shrink-0">{getIcon(note.type)}</div>
                <div>
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">{note.topic}</p>
                  <p className="text-xs font-bold text-slate-700 leading-snug">{note.message}</p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {sources.length > 0 && (
        <div className="mt-6 pt-4 border-t border-slate-100 flex gap-2">
           {sources.map((s, i) => (
             <a key={i} href={s.uri} target="_blank" className="text-[8px] font-black text-slate-400 uppercase hover:text-emerald-600 flex items-center gap-1">
               {s.title.substring(0, 10)}... <ExternalLink size={8} />
             </a>
           ))}
        </div>
      )}
    </div>
  );
};

export default MarketInsights;
