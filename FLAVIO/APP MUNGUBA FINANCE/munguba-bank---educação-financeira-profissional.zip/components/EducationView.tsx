
import React, { useState } from 'react';
import { 
  BookOpen, 
  TrendingUp, 
  Zap, 
  Info, 
  ArrowRight, 
  Brain, 
  Heart, 
  Clock, 
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Lock,
  BarChart3,
  Home,
  ShoppingBag,
  Download,
  CheckCircle2,
  FileText,
  X,
  Book,
  GraduationCap,
  Lightbulb,
  Target
} from 'lucide-react';
import { DashboardStats } from '../types';

interface EducationViewProps {
  stats: DashboardStats;
}

const EducationView: React.FC<EducationViewProps> = ({ stats }) => {
  const [isReading, setIsReading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [currentChapter, setCurrentChapter] = useState(0);
  const [currentPrinciple, setCurrentPrinciple] = useState(0);

  const ebookContent = [
    {
      title: "1. A Importância da Educação Financeira",
      subtitle: "O pilar da sua liberdade",
      content: "Educação financeira não é sobre matemática, é sobre LIBERDADE. No Brasil, crescemos ouvindo que 'dinheiro não traz felicidade', mas a verdade é que a falta dele traz ansiedade e limitações. Aprender a gerir seus recursos é aprender a dizer 'NÃO' para o que é imediato e 'SIM' para o que é vital.",
      points: ["Independência de escolhas", "Paz mental", "Quebra de ciclos de escassez"]
    },
    {
      title: "2. Como a Riqueza é Construída",
      subtitle: "Constância vs. Intensidade",
      content: "Riqueza é fruto de hábitos consistentes. A fórmula é: (Aporte Mensal x Taxa de Retorno) ^ Tempo. O maior erro é esperar ter 'muito' para começar. Quem não cuida de 10 reais, não saberá gerir 1 milhão. A construção começa hoje, com o que você tem.",
      points: ["Tempo: Seu maior ativo", "Pequenos hábitos, grandes fortunas", "Investimento em conhecimento primeiro"]
    },
    {
      title: "3. Os 5 Passos da Educação",
      subtitle: "O roteiro prático",
      content: "1. Diagnóstico: Mapear para onde o dinheiro foge. 2. Eliminação: Acabar com dívidas caras. 3. Reserva: Ter 6 meses de segurança. 4. Estratégia: Definir objetivos claros. 5. Aporte: Investir mensalmente, tratando o investimento como o seu 'pagamento mais importante'.",
      points: ["Clareza absoluta", "Segurança familiar", "Foco no destino"]
    },
    {
      title: "4. Dicionário de Termos",
      subtitle: "Descomplicando o mercado",
      content: "SELIC: Taxa básica da economia. IPCA: O medidor oficial da inflação. DIVIDENDOS: Lucros das empresas distribuídos a você. RENDA FIXA: Emprestar dinheiro para o governo ou bancos em troca de juros. RENDA VARIÁVEL: Tornar-se sócio de grandes negócios.",
      points: ["Selic: Juros do país", "IPCA: Poder de compra", "Dividendos: Renda Passiva"]
    },
    {
      title: "5. A Bússola 50/25/25",
      subtitle: "O equilíbrio perfeito",
      content: "50% CUSTOS FIXOS: Essencial. Meta: Não ultrapassar! 25% ESTILO DE VIDA: O agora. 25% INVESTIMENTOS: O amanhã. O segredo da prosperidade é viver um degrau abaixo do que você ganha, para que o seu futuro seja vários degraus acima.",
      points: ["Mentalidade de Poupador", "Fruição sem Culpa", "Aceleração de Patrimônio"]
    }
  ];

  const principles = [
    {
      title: "Psicologia do Gasto",
      icon: <Brain className="text-purple-500" />,
      content: "Gastamos dinheiro que não temos, para comprar coisas que não precisamos, para impressionar pessoas que não gostamos. A educação financeira cura essa necessidade de validação externa.",
      lesson: "Compre para você, não para os outros."
    },
    {
      title: "O Custo do 'Só Hoje'",
      icon: <Zap className="text-orange-500" />,
      content: "Pequenos luxos diários são os cupins do patrimônio. 15 reais por dia em supérfluos somam 5.400 reais por ano. Isso investido a 1% ao mês vira 1 milhão em 30 anos.",
      lesson: "Valorize os pequenos valores."
    },
    {
      title: "Visão de Longo Prazo",
      icon: <Clock className="text-blue-500" />,
      content: "A maioria das pessoas superestima o que pode fazer em 1 ano e subestima o que pode fazer em 10 anos. Tenha paciência com o processo e pressa com o aporte.",
      lesson: "O tempo é o fermento do dinheiro."
    }
  ];

  const handleDownload = () => {
    setDownloading(true);
    setTimeout(() => {
      setDownloading(false);
      alert("Seu E-book 'Princípios da Prosperidade' foi preparado. Iniciando transferência...");
    }, 1500);
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-6 duration-700 pb-20">
      
      {/* 1. SEÇÃO E-BOOK (DESIGN PREMIUM) */}
      <section className="bg-gradient-to-br from-emerald-950 to-black rounded-[3.5rem] p-10 md:p-16 text-white shadow-2xl relative overflow-hidden group">
        <div className="absolute -top-24 -right-24 p-20 opacity-10 group-hover:scale-110 transition-all duration-1000">
          <BookOpen size={400} />
        </div>
        
        <div className="relative z-10 flex flex-col lg:flex-row gap-16 items-center">
          <div className="w-full lg:w-1/3 flex justify-center">
            {/* Mockup 3D do E-book */}
            <div className="w-64 h-84 bg-white rounded-r-3xl shadow-[25px_25px_50px_-12px_rgba(0,0,0,0.5)] relative flex flex-col overflow-hidden border-l-[15px] border-emerald-500 transform hover:-rotate-3 transition-all duration-500 cursor-pointer" onClick={() => setIsReading(true)}>
               <div className="bg-emerald-600 p-8 h-1/2 flex flex-col justify-end">
                  <Leaf className="w-10 h-10 text-emerald-100 mb-4" />
                  <h4 className="text-white font-black text-lg leading-tight uppercase">Os Princípios da Prosperidade</h4>
               </div>
               <div className="p-8 flex flex-col justify-between flex-1 bg-slate-50">
                  <p className="text-[10px] text-emerald-800 font-black uppercase tracking-[0.4em]">Guia de Elite</p>
                  <div className="pt-4 border-t border-emerald-100 flex items-center justify-between">
                    <span className="text-[11px] font-black italic font-serif text-slate-800">Flávio Mendes</span>
                    <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                  </div>
               </div>
            </div>
          </div>

          <div className="flex-1 space-y-8">
            <div className="flex flex-wrap gap-3">
              <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-black px-4 py-2 rounded-full border border-emerald-500/30 uppercase tracking-[0.2em]">Material Oficial</span>
              <span className="bg-white/5 text-slate-300 text-[10px] font-bold px-4 py-2 rounded-full uppercase tracking-widest border border-white/10">15 Páginas de Valor</span>
            </div>
            
            <h2 className="text-4xl md:text-6xl font-black font-serif italic tracking-tight leading-tight">
              Aprenda a dominar o jogo do dinheiro.
            </h2>
            <p className="text-emerald-100/60 text-lg leading-relaxed max-w-2xl font-medium">
              Um guia intuitivo criado para quem quer sair da teoria e entrar na prática. Explicamos termos complexos em linguagem simples, com gráficos e passos reais para sua independência.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-[11px] font-black uppercase text-emerald-200/80 tracking-wider">
               <div className="flex items-center gap-3"><CheckCircle2 size={18} className="text-emerald-400" /> A importância real</div>
               <div className="flex items-center gap-3"><CheckCircle2 size={18} className="text-emerald-400" /> Nomenclaturas da B3</div>
               <div className="flex items-center gap-3"><CheckCircle2 size={18} className="text-emerald-400" /> Como a riqueza é feita</div>
               <div className="flex items-center gap-3"><CheckCircle2 size={18} className="text-emerald-400" /> Passos da Educação</div>
            </div>

            <div className="flex flex-col sm:flex-row gap-5 pt-6">
              <button 
                onClick={handleDownload}
                disabled={downloading}
                className="flex items-center justify-center gap-4 bg-emerald-500 text-emerald-950 hover:bg-emerald-400 px-10 py-6 rounded-[1.5rem] font-black text-xs uppercase tracking-widest transition-all shadow-2xl active:scale-95 group disabled:opacity-50"
              >
                <Download size={22} className={downloading ? 'animate-bounce' : 'group-hover:translate-y-1 transition-transform'} /> 
                {downloading ? 'Preparando...' : 'Baixar E-book (PDF)'}
              </button>
              <button 
                onClick={() => setIsReading(true)}
                className="flex items-center justify-center gap-4 bg-white/10 text-white hover:bg-white/20 px-10 py-6 rounded-[1.5rem] font-black text-xs uppercase tracking-widest transition-all border border-white/20 backdrop-blur-md"
              >
                <BookOpen size={22} /> Ler Online
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 2. BÚSSOLA E DICIONÁRIO */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        
        {/* Card Bússola Reformulado */}
        <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col gap-8 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform">
             <Target size={120} className="text-emerald-900" />
          </div>
          <div className="space-y-4">
             <div className="bg-emerald-100 w-14 h-14 rounded-2xl flex items-center justify-center text-emerald-600 mb-6">
                <Target size={28} />
             </div>
             <h3 className="text-2xl font-black text-slate-900 tracking-tight italic font-serif">Bússola 50/25/25</h3>
             <p className="text-slate-500 text-xs leading-relaxed font-medium">
                O equilíbrio estratégico para quem busca prosperidade real. 
                <span className="block mt-4 p-4 bg-emerald-50 rounded-2xl border border-emerald-100 text-emerald-900 font-bold italic">
                  "A meta fundamental é NÃO ULTRAPASSAR os 50% de consumo fixo."
                </span>
             </p>
          </div>
          <div className="mt-auto grid grid-cols-3 gap-2">
             <div className="bg-slate-50 p-3 rounded-xl text-center">
                <span className="text-lg font-black text-slate-800">50%</span>
                <p className="text-[7px] font-black text-slate-400 uppercase">Fixo</p>
             </div>
             <div className="bg-slate-50 p-3 rounded-xl text-center">
                <span className="text-lg font-black text-slate-800">25%</span>
                <p className="text-[7px] font-black text-slate-400 uppercase">Estilo</p>
             </div>
             <div className="bg-emerald-600 p-3 rounded-xl text-center shadow-lg shadow-emerald-100">
                <span className="text-lg font-black text-white">25%</span>
                <p className="text-[7px] font-black text-emerald-200 uppercase">Invest.</p>
             </div>
          </div>
        </div>

        {/* Princípios de Conduta (Slider) */}
        <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col relative">
           <div className="flex items-center justify-between mb-10">
              <div className="flex items-center gap-3">
                 <div className="bg-slate-900 p-2.5 rounded-xl text-white"><ShieldCheck size={20}/></div>
                 <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em]">Princípios de Conduta</h3>
              </div>
              <div className="flex gap-2">
                 <button onClick={() => setCurrentPrinciple(prev => Math.max(0, prev - 1))} disabled={currentPrinciple === 0}
                    className="p-2 text-slate-300 hover:text-emerald-600 transition-colors disabled:opacity-20"><ChevronLeft size={24}/></button>
                 <button onClick={() => setCurrentPrinciple(prev => Math.min(principles.length - 1, prev + 1))} disabled={currentPrinciple === principles.length - 1}
                    className="p-2 text-slate-300 hover:text-emerald-600 transition-colors disabled:opacity-20"><ChevronRight size={24}/></button>
              </div>
           </div>
           
           <div className="flex flex-col md:flex-row gap-10 items-start animate-in fade-in duration-500 flex-1">
              <div className="p-6 bg-slate-50 rounded-[2rem] shrink-0 transform hover:scale-105 transition-transform">
                 {principles[currentPrinciple].icon}
              </div>
              <div className="space-y-5">
                 <h4 className="text-3xl font-black text-slate-900 tracking-tight leading-none">{principles[currentPrinciple].title}</h4>
                 <p className="text-base text-slate-600 leading-relaxed italic font-medium">"{principles[currentPrinciple].content}"</p>
                 <div className="flex items-center gap-3 text-[11px] font-black text-emerald-600 uppercase bg-emerald-50 w-fit px-5 py-2.5 rounded-2xl border border-emerald-100">
                    <CheckCircle2 size={16} /> Lição: {principles[currentPrinciple].lesson}
                 </div>
              </div>
           </div>
        </div>
      </section>

      {/* 3. FOOTER EDUCATIVO */}
      <section className="bg-white rounded-[3.5rem] p-12 border border-slate-100 shadow-sm text-center space-y-6 relative overflow-hidden group">
         <div className="absolute inset-0 bg-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
         <Lightbulb className="mx-auto text-emerald-500 mb-2" size={40} />
         <h3 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tighter uppercase italic font-serif leading-tight">
            "Educação financeira não é sobre cálculos,<br/> é sobre o domínio das suas emoções."
         </h3>
         <div className="flex items-center justify-center gap-4">
            <span className="h-px w-10 bg-slate-200"></span>
            <p className="text-[11px] text-slate-400 font-bold uppercase tracking-[0.5em]">Consultoria Profissional em Educação Financeira</p>
            <span className="h-px w-10 bg-slate-200"></span>
         </div>
      </section>

      {/* MODAL DE LEITURA (E-BOOK INTERATIVO) */}
      {isReading && (
        <div className="fixed inset-0 z-[100] bg-slate-950/98 backdrop-blur-2xl flex items-center justify-center p-4 md:p-10 animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-6xl h-full max-h-[900px] rounded-[3.5rem] shadow-2xl flex flex-col md:flex-row overflow-hidden border border-white/10 relative">
            <button 
              onClick={() => setIsReading(false)}
              className="absolute top-8 right-8 z-50 p-4 bg-slate-100 text-slate-500 hover:bg-red-50 hover:text-red-600 rounded-3xl transition-all shadow-sm"
            >
              <X size={24} />
            </button>

            {/* Sidebar do Modal */}
            <div className="w-full md:w-80 bg-emerald-50 p-10 border-r border-emerald-100 overflow-y-auto">
              <div className="mb-12">
                <Leaf className="w-10 h-10 text-emerald-600 mb-4" />
                <h3 className="font-black text-emerald-950 uppercase text-[10px] tracking-[0.4em]">Guia de Estudos</h3>
              </div>
              <div className="space-y-3">
                {ebookContent.map((ch, i) => (
                  <button 
                    key={i}
                    onClick={() => setCurrentChapter(i)}
                    className={`w-full text-left p-5 rounded-[1.5rem] transition-all text-xs font-black uppercase tracking-tight group flex items-center justify-between ${
                      currentChapter === i ? 'bg-emerald-600 text-white shadow-xl' : 'text-emerald-900/50 hover:bg-emerald-100'
                    }`}
                  >
                    <span>{ch.title.split('.')[0]}. {ch.title.split('.')[1]}</span>
                    {currentChapter === i && <ChevronRight size={14} className="animate-in slide-in-from-left-2" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Conteúdo da Página */}
            <div className="flex-1 bg-white p-10 md:p-20 overflow-y-auto scrollbar-hide">
              <div className="max-w-3xl mx-auto space-y-12 animate-in slide-in-from-right-8 duration-500">
                <div className="space-y-6">
                  <span className="text-emerald-500 font-black uppercase text-[11px] tracking-[0.5em] block border-b border-emerald-50 pb-4">Capítulo {currentChapter + 1} de {ebookContent.length}</span>
                  <h2 className="text-5xl font-black text-slate-950 tracking-tighter leading-none">{ebookContent[currentChapter].title}</h2>
                  <p className="text-2xl font-serif italic text-emerald-600/80">{ebookContent[currentChapter].subtitle}</p>
                </div>

                <div className="prose prose-emerald max-w-none">
                  <p className="text-slate-700 leading-relaxed text-xl font-medium">
                    {ebookContent[currentChapter].content}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {ebookContent[currentChapter].points.map((pt, i) => (
                    <div key={i} className="flex items-center gap-4 p-6 bg-slate-50 rounded-[2rem] border border-slate-100 hover:border-emerald-200 transition-all">
                      <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-lg shadow-emerald-200" />
                      <span className="font-black text-slate-900 text-xs uppercase tracking-widest">{pt}</span>
                    </div>
                  ))}
                </div>

                {/* Infográfico Placeholder */}
                <div className="bg-emerald-50/50 h-64 rounded-[3rem] border-2 border-dashed border-emerald-200/50 flex flex-col items-center justify-center text-emerald-300 gap-4">
                   <div className="bg-white p-5 rounded-3xl shadow-sm"><BarChart3 size={48} /></div>
                   <p className="text-[11px] font-black uppercase tracking-[0.3em]">Ilustração Educativa de Apoio</p>
                </div>
              </div>

              <div className="max-w-3xl mx-auto mt-20 pt-10 border-t border-slate-50 flex justify-between items-center">
                 <button 
                  onClick={() => setCurrentChapter(prev => Math.max(0, prev - 1))}
                  disabled={currentChapter === 0}
                  className="flex items-center gap-3 text-[11px] font-black uppercase tracking-widest text-slate-400 hover:text-emerald-600 disabled:opacity-20 transition-all"
                 >
                    <ChevronLeft size={24} /> Anterior
                 </button>
                 <div className="flex gap-1.5">
                    {ebookContent.map((_, i) => (
                        <div key={i} className={`w-2 h-2 rounded-full transition-all ${currentChapter === i ? 'w-8 bg-emerald-600' : 'bg-slate-200'}`} />
                    ))}
                 </div>
                 <button 
                  onClick={() => setCurrentChapter(prev => Math.min(ebookContent.length - 1, prev + 1))}
                  disabled={currentChapter === ebookContent.length - 1}
                  className="flex items-center gap-3 text-[11px] font-black uppercase tracking-widest text-slate-400 hover:text-emerald-600 disabled:opacity-20 transition-all"
                 >
                    Próximo <ChevronRight size={24} />
                 </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Ícone Munguba Customizado
const Leaf = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8a13 13 0 0 1-10 10Z"/><path d="M9 21a7 7 0 0 0 1-8.58"/><path d="M20 10c0 5.523-4.477 10-10 10s-10-4.477-10-10 4.477-10 10-10 10 4.477 10 10z"/>
  </svg>
);

export default EducationView;
